!-------------------------------------------------------------------------------
!> MACRO for OpenMP
!!
!! @par Description
!!          OpenMP schedule macros
!!
!! @author Team SCALE
!!
!! @par History
!! @li      2013-8-2 (T.Kameyama)  [new]
!!
!<
!-------------------------------------------------------------------------------
#define OMP_SCHEDULE_ schedule(static)
