  character(len=*), parameter :: LIBVERSION = VERSION_MACRO
