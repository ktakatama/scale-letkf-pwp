  character(len=*), parameter :: VERSION = VERSION_MACRO

