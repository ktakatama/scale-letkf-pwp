#!/bin/sh
#PBS -N real_pwp
#PBS -l nodes=1:ppn=16
##PBS -l walltime=00:30:00
#PBS -W umask=027
##PBS -k oe

ulimit -s unlimited
cd /home/takatama/data10_work/SCALE/model/scale-5.2.1.PWP.wip/scale-rm/test/tutorial/real_pwp/experiment/pp

export MPI_XPMEM_ENABLED=disabled
HOSTLIST=$(cat $PBS_NODEFILE | sort | uniq)
HOSTLIST=$(echo $HOSTLIST | sed 's/  */,/g')
#export MPI_UNIVERSE="$HOSTLIST 16"

export OMP_NUM_THREADS=1
#export PARALLEL=1

export FORT_FMT_RECL=400

cd $PBS_O_WORKDIR

rm -f machinefile
cp -f $PBS_NODEFILE machinefile

mpirun -np 16 ./scale-rm_pp pp.d01.conf



