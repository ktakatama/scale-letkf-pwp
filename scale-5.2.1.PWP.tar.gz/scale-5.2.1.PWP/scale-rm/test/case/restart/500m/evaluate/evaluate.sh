#! /bin/bash -x

ruby ./evaluate/diff.rb restartA_*.nc restartB2_*.nc
